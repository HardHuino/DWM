/* menu.js */


function actionm1() {
  //alert("m1");
  let s2 =document.getElementById("smenu2");
  s2.style.display="none";
  let s4 =document.getElementById("smenu4");
  s4.style.display="none";
}

function actionm2() {
  //alert("m2");
  let s2 =document.getElementById("smenu2");
  let s4 =document.getElementById("smenu4");
  if (s2.style.display=="none")
  {
    s4.style.display="none";
    s2.style.display="block";
  }
  else
  {
    s2.style.display="none";
  }
}

function actionm3() {
  //alert("m3");
  let s2 =document.getElementById("smenu2");
  s2.style.display="none";
  let s4 =document.getElementById("smenu4");
  s4.style.display="none";
}

function actionm4() {
  //alert("m4");
  let s2 =document.getElementById("smenu2");
  let s4 =document.getElementById("smenu4");
  if (s4.style.display=="none")
  {
    s2.style.display="none";
    s4.style.display="block";
  }
  else
  {
    s4.style.display="none";
  }
}


/* Programme principal */
let m1 = document.getElementById("m1");
m1.addEventListener("click", actionm1);
let m2 = document.getElementById("m2");
m2.addEventListener("click", actionm2);
let m3 = document.getElementById("m3");
m3.addEventListener("click", actionm3);
let m4 = document.getElementById("m4");
m4.addEventListener("click", actionm4);
