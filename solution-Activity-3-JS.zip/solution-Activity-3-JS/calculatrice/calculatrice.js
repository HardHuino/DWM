/* calculatrice.js */

function hasard(n) {
  return Math.ceil(Math.random()*n);
}

function verif() {
  let reponse=document.getElementById("rep").value;
  console.log(parseInt(reponse));
  if (reponse==result)
  {
    alert("Bonne réponse, Bravo!");
    score+=1;
  }
  else
  {
    alert("Raté, la réponse était: "+result);
  }
  nb+=1;
  result=lancement();
}

function lancement() {
  document.getElementById("rep").value="";
  
  document.getElementById("total").innerHTML=nb;
  document.getElementById("score").innerHTML=score;
  if (score>=(nb/2))
    document.getElementById("score").style.color="green";
  else
    document.getElementById("score").style.color="red";
  let v1=hasard(10);
  let v2=hasard(10);
  document.getElementById("v1").innerHTML=v1;
  document.getElementById("v2").innerHTML=v2;
  return v1*v2;
}

/* Programme principal */
let score=0;
let result=0;
let nb=0

result=lancement();
let b = document.getElementById("button");
b.addEventListener("click", verif); // attention l'élément button doit
				   // exister avant que le script ne
				   // soit exécuté --> il faut appeler
				   // le script en fin de page.
				   // ou rajouter defer (plus efficace)
				   // <script src="calculatrice.js" defer></script>
let f = document.getElementById("formu");
f.addEventListener("submit", function (e) {
  e.preventDefault(); // empêche le fonctionnement par défaut quand on
		      // appuie sur Entrée (i.e., submit) dans un
		      // formulaire: on empêche la soumission du
		      // formulaire et donc le rechargement de la page
		      // ici
  verif();
});
