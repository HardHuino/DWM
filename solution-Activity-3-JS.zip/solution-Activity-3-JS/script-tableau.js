            function affichage (s) {
              alert("Nous interrompons cette page Web pour une petite annonce..." + s);

              let myTable = ['Anastasia', 'Bezerianos', 'Paris-Saclay'];

              for (let i in myTable)
              {
                console.log( myTable[i]);
              }

            }