alert('Hello world!');

let text = prompt('Tapez un numero pour compter :' );

alert('you typed ' + text);

let c = parseInt(text,10);
let ci = 0; 

while (Number.isNaN(c) && ci < 3) {
	let text = prompt('Tapez un numero svp : ' ); 
	let c = parseInt(text,10); 
	console.log(c);
	++ci;
}

if(ci >= 3){
	alert('3 failed attempts');
}
else{
	for (let i = 0; i<c; ++i){
		console.log('count '+i);
	}
}