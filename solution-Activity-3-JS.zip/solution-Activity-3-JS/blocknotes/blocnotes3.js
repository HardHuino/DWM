/* blocnotes3.js */


function init() {
  /* var button = document.getElementById("ajouter");
  button.onclick = gestionClicBouton; 
  alert("init"); */
  console.log("lancement");
  chargementListenotes();
}

function gestionClicBouton() {
  var textInput = document.getElementById("entreenote");
  var note = textInput.value;

  if (note == "") {
    alert("Veuillez entrer une note");
  }
  else {
    console.log("Ajout de " + note);
    let li = document.createElement("li");
    li.innerHTML = note;
    li.onclick= gestionClicNote;
    let ul = document.getElementById("listenotes");
    ul.appendChild(li);
    sauve(note);

  }
}

function gestionClicNote(evenement) {
  let note = evenement.target;
  console.log("La note est: " + note.innerHTML);
  let ul = document.getElementById("listenotes");
  ul.removeChild(note);
  efface(note.innerHTML);
}
