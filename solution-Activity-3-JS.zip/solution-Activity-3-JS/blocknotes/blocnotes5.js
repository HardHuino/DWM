/* blocnotes5.js */


function init() {
  /* var button = document.getElementById("ajouter");
  button.onclick = gestionClicBouton; 
  alert("init"); */
  console.log("lancement");
  chargementListenotes();
}

function gestionClicBouton() {
  let textInput = document.getElementById("entreenote");
  let note = textInput.value;

  if (note == "") {
    alert("Veuillez entrer une note");
  }
  else {

    let r = sauve(note);
    if (r==1) {
      console.log("Ajout de " + note);
      let li = document.createElement("li");
      li.innerHTML = note;
      li.onclick= gestionClicNote;
      let ul = document.getElementById("listenotes");
      ul.appendChild(li);
    }

  }
}

function gestionClicNote(evenement) {

  /* http://www.w3schools.com/jsref/met_win_confirm.asp */
  let r = confirm("Effacer la note?");
  if (r == true) {
    console.log("True");
    
    let note = evenement.target;
    console.log("La note est: " + note.innerHTML);
    let ul = document.getElementById("listenotes");
    ul.removeChild(note);
    efface(note.innerHTML);

  } else { console.log("False"); }


}
